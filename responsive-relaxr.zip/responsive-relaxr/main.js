// document.getElementsByTagName("mobileMenu")[0].addEventListener("click",function(){
// 	if(!this.parentNode.getAttribute("class")){
// 		this.parentNode.setAttribute("class","slideDown");
// 	}
// 	else{
// 		this.parentNode.removeAttribute("class");
// 	}
// });

$(document).ready(function() {

	$('a #mobileMenu').click(function(e){
	   e.preventDefault()
	// $('.learnmore-btn').hide();
		$('header nav ul').show();
         console.log("this worked");   
     });
});

// $(document).ready(function(){
//     $("#hide").click(function(){
//         $("p").hide();
//     });
//     $("#show").click(function(){
//         $("p").show();
//     });
// });